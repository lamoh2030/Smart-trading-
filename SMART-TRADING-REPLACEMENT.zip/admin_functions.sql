-- Run this in Supabase SQL Editor after confirming the base schema exists.
-- This function lets admins add a trade record without exposing service-role keys.
create or replace function public.admin_add_trade(
  p_user_id uuid,
  p_asset text,
  p_trade_type text,
  p_amount numeric,
  p_profit_loss numeric
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  new_id uuid;
begin
  if not public.is_admin() then
    raise exception 'Admin access required';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Trade amount must be greater than zero';
  end if;

  if p_trade_type not in ('BUY', 'SELL') then
    raise exception 'Trade type must be BUY or SELL';
  end if;

  if p_asset is null or length(trim(p_asset)) = 0 then
    raise exception 'Asset is required';
  end if;

  insert into public.trades(user_id, asset, trade_type, amount, profit_loss)
  values (p_user_id, trim(p_asset), p_trade_type, p_amount, coalesce(p_profit_loss, 0))
  returning id into new_id;

  return new_id;
end;
$$;

revoke all on function public.admin_add_trade(uuid,text,text,numeric,numeric) from public;
grant execute on function public.admin_add_trade(uuid,text,text,numeric,numeric) to authenticated;

-- Restrict profile edits so users cannot change their own role.
revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;
