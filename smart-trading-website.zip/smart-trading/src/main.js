import { createClient } from '@supabase/supabase-js';
import './style.css';

const env = import.meta.env;
const supabase = (env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY)
  ? createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY) : null;

const wallets = [
  {network:'TRON (TRC20)', asset:'USDT', address:'TEDtgPcU3mfe2aYymaUtVkCzsc6N4TCuRv'},
  {network:'BNB Smart Chain (BEP20)', asset:'USDT / supported BEP20 assets', address:'0x1606702e91d06692efe611d90254049926aa4083'},
  {network:'Solana', asset:'SOL / supported SPL assets', address:'EDZyijce2kbAcCGh6ow6Q3gHsrHkrspj4afms9d2fXCa'}
];

let session = null, profile = null, active = 'overview';
const app = document.querySelector('#app');
const money = n => '$' + Number(n || 0).toFixed(2);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const msg = (s, bad=false) => { const el=document.querySelector('#notice'); if(el){el.textContent=s;el.className='notice '+(bad?'bad':'good');} };
const call = async (query) => { const {data,error}=await query; if(error) throw error; return data; };

function shell(content) {
  app.innerHTML = `<header><a class="brand" href="#">◈ <span>SMART</span> TRADING</a><div class="top-right">${profile ? `<span class="muted">${esc(profile.full_name || session.user.email)}</span><button id="logout" class="outline small">Log out</button>` : '<span class="pill">CRYPTO ACCOUNT PORTAL</span>'}</div></header>${content}`;
  document.querySelector('#logout')?.addEventListener('click', async()=>{await supabase.auth.signOut(); session=null; profile=null; renderAuth();});
}
function renderAuth() {
  shell(`<main class="auth-wrap"><section class="hero"><div class="eyebrow">SMARTER CRYPTO MANAGEMENT</div><h1>Trade records.<br><span>Clear visibility.</span></h1><p>Manage your account, submit crypto deposits, follow trade performance and invite friends.</p><div class="hero-tags"><span>TRC20</span><span>BEP20</span><span>SOLANA</span><span>USD</span></div></section>
  <section class="panel auth-panel"><div class="tabs"><button class="tab selected" data-tab="login">Log in</button><button class="tab" data-tab="signup">Create account</button><button class="tab" data-tab="verify">Verify email</button></div>
  <div id="notice" class="notice"></div>
  <form id="auth-form"><h2 id="auth-title">Welcome back</h2><label id="name-wrap" class="hidden">Full name<input id="name" autocomplete="name"></label><label>Email address<input id="email" type="email" required autocomplete="email"></label><label id="pass-wrap">Password<input id="password" type="password" minlength="8" required autocomplete="current-password"></label><label id="code-wrap" class="hidden">Six-digit email code<input id="code" inputmode="numeric" maxlength="6" pattern="[0-9]{6}"></label><button class="primary full" id="auth-submit">Log in</button></form>
  <p class="fine">Never share wallet seed phrases or private keys. Smart Trading will never ask for them.</p></section></main>`);
  let tab='login';
  const setTab=t=>{tab=t; document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('selected',b.dataset.tab===t)); document.querySelector('#name-wrap').classList.toggle('hidden',t!=='signup');document.querySelector('#pass-wrap').classList.toggle('hidden',t==='verify');document.querySelector('#code-wrap').classList.toggle('hidden',t!=='verify');document.querySelector('#auth-title').textContent=t==='login'?'Welcome back':t==='signup'?'Create your account':'Verify your email';document.querySelector('#auth-submit').textContent=t==='login'?'Log in':t==='signup'?'Create account':'Verify code';document.querySelector('#password').required=t!=='verify';document.querySelector('#code').required=t==='verify';};
  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.tab)));
  document.querySelector('#auth-form').addEventListener('submit', async e=>{
    e.preventDefault();
    if(!supabase){msg('Add your Supabase URL and publishable/anon key to the Vercel environment variables first.',true);return;}
    const email=document.querySelector('#email').value.trim(), password=document.querySelector('#password').value, code=document.querySelector('#code').value.trim();
    try{
      if(tab==='signup'){
        const ref=new URLSearchParams(location.search).get('ref');
        const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:document.querySelector('#name').value.trim(),referred_by:ref||null}}});
        if(error) throw error;
        msg('Account created. Check your email for the six-digit verification code, then open Verify email.');
        setTab('verify');
      } else if(tab==='verify'){
        const {error}=await supabase.auth.verifyOtp({email,token:code,type:'signup'}); if(error) throw error;
        msg('Email verified. You can now log in.'); setTab('login');
      } else {
        const {data,error}=await supabase.auth.signInWithPassword({email,password}); if(error) throw error;
        session=data.session; await loadProfile(); renderDashboard();
      }
    }catch(err){msg(err.message||'Something went wrong.',true);}
  });
}
async function loadProfile(){
  profile=await call(supabase.from('profiles').select('*').eq('id',session.user.id).single());
}
async function getRows(table, select='*', order='created_at'){
  return await call(supabase.from(table).select(select).order(order,{ascending:false}).limit(100));
}
function nav(){
  const links=[['overview','Overview'],['deposit','Deposit'],['trades','My trades'],['referrals','Referrals'],['withdraw','Withdraw'],['history','History']];
  if(profile.role==='admin') links.push(['admin','Admin']);
  return `<aside>${links.map(([id,label])=>`<button class="navlink ${active===id?'on':''}" data-page="${id}">${label}</button>`).join('')}</aside>`;
}
async function renderDashboard(){
  shell(`<div class="layout">${nav()}<main class="content"><div id="page"></div></main></div>`);
  document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>{active=b.dataset.page;renderDashboard();}));
  await renderPage();
}
async function renderPage(){
  const page=document.querySelector('#page'); page.innerHTML='<div class="loading">Loading your account…</div>';
  try{
    if(active==='overview'){
      const [deps,trades]=await Promise.all([getRows('deposits'),getRows('trades')]);
      const approved=deps.filter(x=>x.status==='approved').reduce((s,x)=>s+Number(x.usd_amount),0);
      const pnl=trades.reduce((s,x)=>s+Number(x.profit_loss||0),0);
      page.innerHTML=`<div class="page-head"><div><div class="eyebrow">YOUR ACCOUNT</div><h1>Overview</h1><p class="muted">Welcome, ${esc(profile.full_name||session.user.email)}</p></div><span class="pill">USD ACCOUNT</span></div>
      <div class="cards"><div class="stat"><small>Approved deposits</small><strong>${money(approved)}</strong><em>Verified deposits only</em></div><div class="stat"><small>Recorded profit / loss</small><strong class="${pnl>=0?'positive':'negative'}">${money(pnl)}</strong><em>Based on admin-entered trades</em></div><div class="stat"><small>Account status</small><strong class="status">${esc(profile.status||'active')}</strong><em>Contact support for assistance</em></div></div>
      <div class="panel"><h3>Recent activity</h3>${deps.length?table(['Date','Network','Amount','Status'],deps.slice(0,5).map(x=>[new Date(x.created_at).toLocaleDateString(),x.network,money(x.usd_amount),x.status])):'<p class="muted">No deposit records yet.</p>'}</div>`;
    } else if(active==='deposit'){
      page.innerHTML=`<div class="page-head"><div><div class="eyebrow">FUNDING</div><h1>Make a deposit</h1><p class="muted">Send only the asset supported by the selected network.</p></div></div>
      <div class="panel"><h3>Official receiving wallets</h3><div class="wallet-list">${wallets.map((w,i)=>`<div class="wallet"><div><b>${w.network}</b><small>${w.asset}</small><code>${w.address}</code></div><button class="outline small copy" data-copy="${w.address}">Copy address</button></div>`).join('')}</div><p class="warning">Network warning: sending funds on the wrong network or sending an unsupported token may result in permanent loss. Confirm the asset and network before transferring.</p></div>
      <div class="panel"><h3>Submit transaction for review</h3><form id="deposit-form" class="form-grid"><label>Network<select id="network">${wallets.map(w=>`<option>${w.network}</option>`).join('')}</select></label><label>Amount in USD<input id="amount" type="number" min="1" step="0.01" required></label><label class="span2">Transaction hash / reference<input id="txid" required minlength="8"></label><button class="primary">Submit for manual review</button></form></div>`;
      document.querySelectorAll('.copy').forEach(b=>b.onclick=()=>navigator.clipboard.writeText(b.dataset.copy).then(()=>msg('Wallet address copied.')));
      document.querySelector('#deposit-form').onsubmit=async e=>{e.preventDefault();try{await call(supabase.from('deposits').insert({user_id:session.user.id,network:document.querySelector('#network').value,usd_amount:Number(document.querySelector('#amount').value),tx_hash:document.querySelector('#txid').value.trim()}));msg('Deposit submitted. It will not be credited until an administrator verifies it.');e.target.reset();}catch(err){msg(err.message,true);}};
    } else if(active==='trades'){
      const rows=await getRows('trades'); page.innerHTML=`<div class="page-head"><div><div class="eyebrow">PERFORMANCE</div><h1>My trades</h1></div></div><div class="panel">${rows.length?table(['Date','Asset','Side','Quantity','P/L'],rows.map(x=>[new Date(x.created_at).toLocaleDateString(),x.asset,x.side,x.quantity,money(x.profit_loss)])):'<p class="muted">No trades have been assigned to your account yet.</p>'}</div>`;
    } else if(active==='referrals'){
      const referrals=await call(supabase.from('profiles').select('id,full_name,created_at').eq('referred_by',session.user.id));
      const commissions=await getRows('referral_commissions');
      const link=`${location.origin}${location.pathname}?ref=${session.user.id}`;
      page.innerHTML=`<div class="page-head"><div><div class="eyebrow">INVITE & EARN</div><h1>Referral program</h1><p class="muted">Share your personal invitation link.</p></div></div><div class="panel"><h3>Your referral link</h3><div class="copyline"><input readonly value="${link}" id="ref-link"><button class="primary" id="copy-ref">Copy link</button></div><div class="cards three"><div class="stat"><small>Level 1</small><strong>$10</strong><em>Qualifying deposit of at least $50 and first trade</em></div><div class="stat"><small>Level 2</small><strong>$3</strong><em>Second-level qualifying referral</em></div><div class="stat"><small>Level 3</small><strong>$1</strong><em>Third-level qualifying referral</em></div></div><p class="fine">Rewards are subject to admin verification, the published referral rules and applicable law. No reward is guaranteed merely for signing up.</p></div><div class="panel"><h3>Your direct referrals (${referrals.length})</h3>${referrals.length?table(['Name','Joined'],referrals.map(x=>[x.full_name||'Member',new Date(x.created_at).toLocaleDateString()])):'<p class="muted">No direct referrals yet.</p>'}</div><div class="panel"><h3>Commission history</h3>${commissions.length?table(['Level','Amount','Status'],commissions.map(x=>[x.level,money(x.amount_usd),x.status])):'<p class="muted">No commissions yet.</p>'}</div>`;
      document.querySelector('#copy-ref').onclick=()=>navigator.clipboard.writeText(link).then(()=>msg('Referral link copied.'));
    } else if(active==='withdraw'){
      const rows=await getRows('withdrawal_requests');
      page.innerHTML=`<div class="page-head"><div><div class="eyebrow">PAYOUTS</div><h1>Withdrawal request</h1></div></div><div class="panel"><p class="warning">Withdrawal requests are reviewed manually. Do not submit a private key or recovery phrase.</p><form id="withdraw-form" class="form-grid"><label>Amount (USD)<input id="wamount" type="number" min="1" step=".01" required></label><label>Asset / network<input id="wasset" placeholder="e.g. USDT TRC20" required></label><label class="span2">Your receiving wallet address<input id="waddress" required></label><button class="primary">Submit request</button></form></div><div class="panel"><h3>Previous requests</h3>${rows.length?table(['Date','Amount','Network','Status'],rows.map(x=>[new Date(x.created_at).toLocaleDateString(),money(x.usd_amount),x.asset_network,x.status])):'<p class="muted">No withdrawal requests.</p>'}</div>`;
      document.querySelector('#withdraw-form').onsubmit=async e=>{e.preventDefault();try{await call(supabase.from('withdrawal_requests').insert({user_id:session.user.id,usd_amount:Number(document.querySelector('#wamount').value),asset_network:document.querySelector('#wasset').value.trim(),wallet_address:document.querySelector('#waddress').value.trim()}));msg('Withdrawal request submitted for admin review.');e.target.reset();}catch(err){msg(err.message,true);}};
    } else if(active==='history'){
      const [d,w,c]=await Promise.all([getRows('deposits'),getRows('withdrawal_requests'),getRows('referral_commissions')]);
      page.innerHTML=`<div class="page-head"><div><div class="eyebrow">RECORDS</div><h1>Transaction history</h1></div></div><div class="panel"><h3>Deposits</h3>${d.length?table(['Date','Network','USD','Status'],d.map(x=>[new Date(x.created_at).toLocaleDateString(),x.network,money(x.usd_amount),x.status])):'<p class="muted">No deposits.</p>'}</div><div class="panel"><h3>Withdrawals</h3>${w.length?table(['Date','Amount','Network','Status'],w.map(x=>[new Date(x.created_at).toLocaleDateString(),money(x.usd_amount),x.asset_network,x.status])):'<p class="muted">No withdrawals.</p>'}</div>`;
    } else if(active==='admin' && profile.role==='admin'){
      const [users,deps,withdrawals,trades]=await Promise.all([getRows('profiles'),getRows('deposits'),getRows('withdrawal_requests'),getRows('trades')]);
      page.innerHTML=`<div class="page-head"><div><div class="eyebrow">CONTROL CENTER</div><h1>Admin dashboard</h1><p class="muted">Administrative actions are logged in the database.</p></div></div><div class="cards"><div class="stat"><small>Users</small><strong>${users.length}</strong></div><div class="stat"><small>Pending deposits</small><strong>${deps.filter(x=>x.status==='pending').length}</strong></div><div class="stat"><small>Pending withdrawals</small><strong>${withdrawals.filter(x=>x.status==='pending').length}</strong></div></div>
      <div class="panel"><h3>Pending deposits</h3>${deps.filter(x=>x.status==='pending').length?deps.filter(x=>x.status==='pending').map(x=>`<div class="admin-row"><span>${esc(x.network)} · ${money(x.usd_amount)}<small>${esc(x.tx_hash)}</small></span><span><button class="primary small" data-deposit="${x.id}" data-action="approve">Approve</button> <button class="danger small" data-deposit="${x.id}" data-action="reject">Reject</button></span></div>`).join(''):'<p class="muted">No pending deposits.</p>'}</div>
      <div class="panel"><h3>Record a trade for a user</h3><form id="trade-form" class="form-grid"><label>User<select id="trade-user">${users.map(u=>`<option value="${u.id}">${esc(u.full_name||u.email||u.id)}</option>`).join('')}</select></label><label>Asset<input id="tasset" placeholder="BTC/USDT" required></label><label>Side<select id="tside"><option>BUY</option><option>SELL</option></select></label><label>Quantity<input id="tqty" type="number" step="any" min="0" required></label><label>Profit / loss (USD)<input id="tpnl" type="number" step=".01" value="0" required></label><label class="span2">Notes<input id="tnotes"></label><button class="primary">Save trade record</button></form></div>
      <div class="panel"><h3>Users</h3>${users.length?table(['User','Role','Status'],users.map(u=>[u.full_name||u.id,u.role,u.status])):'<p>No users</p>'}</div>`;
      document.querySelectorAll('[data-deposit]').forEach(b=>b.onclick=async()=>{try{await call(supabase.rpc('admin_review_deposit',{p_deposit_id:b.dataset.deposit,p_decision:b.dataset.action}));msg('Deposit review saved.');await renderPage();}catch(err){msg(err.message,true);}});
      document.querySelector('#trade-form').onsubmit=async e=>{e.preventDefault();try{await call(supabase.from('trades').insert({user_id:document.querySelector('#trade-user').value,asset:document.querySelector('#tasset').value.trim(),side:document.querySelector('#tside').value,quantity:Number(document.querySelector('#tqty').value),profit_loss:Number(document.querySelector('#tpnl').value),notes:document.querySelector('#tnotes').value}));msg('Trade record saved.');e.target.reset();}catch(err){msg(err.message,true);}};
    } else { active='overview'; return renderPage(); }
  }catch(err){page.innerHTML=`<div class="panel"><h3>Could not load this section</h3><p class="badtext">${esc(err.message)}</p><p class="fine">Check that the Supabase schema has been installed and your account has the required access.</p></div>`;}
}
function table(headers, rows){return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;}

async function start(){
  if(!supabase){renderAuth();msg('Setup required: configure Supabase environment variables.');return;}
  const {data}=await supabase.auth.getSession(); session=data.session;
  if(session){try{await loadProfile();renderDashboard();}catch{renderAuth();}}else renderAuth();
  supabase.auth.onAuthStateChange(async(_event,s)=>{session=s;if(!s){profile=null;renderAuth();}});
}
start();
