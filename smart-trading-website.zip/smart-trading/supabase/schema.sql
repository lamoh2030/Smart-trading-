-- SMART TRADING database schema
-- Run in Supabase SQL Editor. Then promote your own profile to admin as described in README.md.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role text not null default 'user' check (role in ('user','admin')),
  status text not null default 'active' check (status in ('active','suspended')),
  referred_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  network text not null,
  usd_amount numeric(18,2) not null check (usd_amount > 0),
  tx_hash text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(network, tx_hash)
);

create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  asset text not null,
  side text not null check (side in ('BUY','SELL')),
  quantity numeric(28,10) not null check (quantity > 0),
  profit_loss numeric(18,2) not null default 0,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.referral_commissions (
  id uuid primary key default gen_random_uuid(),
  earner_id uuid not null references public.profiles(id),
  referred_user_id uuid not null references public.profiles(id),
  level integer not null check (level between 1 and 3),
  amount_usd numeric(18,2) not null check (amount_usd > 0),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  unique(earner_id,referred_user_id,level)
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  usd_amount numeric(18,2) not null check (usd_amount > 0),
  asset_network text not null,
  wallet_address text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected','paid')),
  reviewed_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and status='active') $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
declare ref_id uuid;
begin
  begin ref_id := nullif(new.raw_user_meta_data->>'referred_by','')::uuid;
  exception when others then ref_id := null; end;
  if ref_id = new.id then ref_id := null; end if;
  insert into public.profiles(id,email,full_name,referred_by)
  values(new.id,new.email,new.raw_user_meta_data->>'full_name',ref_id)
  on conflict(id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.deposits enable row level security;
alter table public.trades enable row level security;
alter table public.referral_commissions enable row level security;
alter table public.withdrawal_requests enable row level security;

create policy "profile read own or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());
create policy "profile update own basic" on public.profiles for update to authenticated
using (id=auth.uid()) with check (id=auth.uid() and role='user');

create policy "deposit read own or admin" on public.deposits for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "user submit deposit" on public.deposits for insert to authenticated
with check (user_id=auth.uid() and status='pending');

create policy "trade read own or admin" on public.trades for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "admin insert trade" on public.trades for insert to authenticated
with check (public.is_admin() and created_by=auth.uid());

create policy "commission read own or admin" on public.referral_commissions for select to authenticated
using (earner_id=auth.uid() or public.is_admin());

create policy "withdrawal read own or admin" on public.withdrawal_requests for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "user submit withdrawal" on public.withdrawal_requests for insert to authenticated
with check (user_id=auth.uid() and status='pending');

create or replace function public.admin_review_deposit(p_deposit_id uuid,p_decision text)
returns void language plpgsql security definer set search_path=public
as $$
declare d public.deposits%rowtype; u public.profiles%rowtype; p1 uuid; p2 uuid; p3 uuid;
begin
  if not public.is_admin() then raise exception 'Admin access required'; end if;
  if p_decision not in ('approve','reject') then raise exception 'Invalid decision'; end if;
  select * into d from public.deposits where id=p_deposit_id for update;
  if not found then raise exception 'Deposit not found'; end if;
  if d.status <> 'pending' then raise exception 'Deposit already reviewed'; end if;
  update public.deposits set status=case when p_decision='approve' then 'approved' else 'rejected' end,
    reviewed_by=auth.uid(), reviewed_at=now() where id=p_deposit_id;
  if p_decision='approve' and d.usd_amount >= 50 then
    select * into u from public.profiles where id=d.user_id;
    p1:=u.referred_by;
    if p1 is not null then
      insert into public.referral_commissions(earner_id,referred_user_id,level,amount_usd,status)
      values(p1,d.user_id,1,10,'pending') on conflict do nothing;
      select referred_by into p2 from public.profiles where id=p1;
      if p2 is not null then
        insert into public.referral_commissions(earner_id,referred_user_id,level,amount_usd,status)
        values(p2,d.user_id,2,3,'pending') on conflict do nothing;
        select referred_by into p3 from public.profiles where id=p2;
        if p3 is not null then
          insert into public.referral_commissions(earner_id,referred_user_id,level,amount_usd,status)
          values(p3,d.user_id,3,1,'pending') on conflict do nothing;
        end if;
      end if;
    end if;
  end if;
end $$;

grant execute on function public.admin_review_deposit(uuid,text) to authenticated;

-- Prevent clients from changing privileged/admin records directly.
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;
