# SMART TRADING — deployment package

This is a deployable Vite + Supabase starter for the agreed Smart Trading workflow. It includes email/password registration, email OTP verification, user dashboard, manual crypto-deposit submissions, admin deposit review, manual trade records, referral tracking and withdrawal requests.

## Important before accepting real money

This package is an operational starting point, not a guarantee of regulatory approval or a fully audited custody/exchange system. It does **not** custody funds, connect to Binance for execution, automatically verify blockchain transfers, or automatically send withdrawals. Deposit submissions are manually reviewed. Do not advertise guaranteed returns. Obtain local legal/compliance advice and a security review before accepting customer funds.

The public receiving addresses supplied for this build are included in `src/main.js`:
- TRON / TRC20: `TEDtgPcU3mfe2aYymaUtVkCzsc6N4TCuRv`
- BNB Smart Chain / BEP20: `0x1606702e91d06692efe611d90254049926aa4083`
- Solana: `EDZyijce2kbAcCGh6ow6Q3gHsrHkrspj4afms9d2fXCa`

A wallet address format does not prove that every token is supported. Before launch, verify ownership, asset compatibility, network, and test deposits with tiny amounts. Never add seed phrases or private keys to this project.

## 1. Create Supabase project
1. Create a new project at https://supabase.com/dashboard.
2. In Project Settings → API, copy the Project URL and the publishable/anon key.
3. In SQL Editor, run all of `supabase/schema.sql`.
4. In Authentication → Providers → Email, enable email sign-ups and email confirmations.
5. Configure the email template to send a six-digit OTP token (the template should include `{{ .Token }}`), and configure your site URL/redirect URLs for your Vercel domain and local development.

## 2. Make your account admin
1. Register your own account through the website and verify your email.
2. In Supabase SQL Editor, run this query, replacing the email:
   `update public.profiles set role='admin' where email='YOUR-ADMIN-EMAIL';`
3. Sign out and sign back in. The Admin menu will appear.

## 3. Run locally
1. Install Node.js (current LTS).
2. Extract this ZIP and open the folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and fill in your Supabase URL and publishable/anon key.
5. Run `npm run dev` and open the local URL shown by Vite.

## 4. Deploy to Vercel
1. Upload the extracted project to a new GitHub repository.
2. In Vercel, import that repository.
3. Add environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy. Add the deployed domain to Supabase Authentication URL configuration.

## Referral rules currently implemented
The system assigns a referral tree from the referral link. When an admin approves a deposit of at least $50, it creates pending commissions for:
- Level 1: $10
- Level 2: $3
- Level 3: $1

**Important qualification gap:** The current database function triggers the referral commission on an approved deposit of at least $50; it does not yet verify that the user has completed a qualifying trade. Before production, add an admin-controlled qualifying-trade approval step and make the commission trigger require both the approved deposit and qualifying trade. Do not pay commissions until that rule is implemented and tested.

## Current limitations to resolve before production
- The admin page currently supports deposit approval/rejection and manual trade entry. Withdrawal review, commission approval/payout, balance ledger, support, audit log and robust admin user management need additional backend functions and UI.
- The displayed approved-deposit total is a record total, not a withdrawable wallet balance.
- Referral commissions are pending records only; they are not cash balances.
- No Binance API keys are used. Never put secret keys in frontend environment variables.
- The supplied EVM address was identified as BEP20 by the user; the app labels it BNB Smart Chain. Confirm the exact supported token(s) before deposits.
- Solana address supports only assets you explicitly verify and announce.

This starter should be treated as a staged build. Test with a private test account and no real funds first.
