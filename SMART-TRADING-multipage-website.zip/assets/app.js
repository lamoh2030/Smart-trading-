'use strict';
const SUPABASE_URL='https://eimekgiuholthajlzspd.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_3eLRu7SvLaPlA0tWb1eepg_4-evkc8m';
const db=window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
const $=id=>document.getElementById(id);
let currentUser=null,currentProfile=null;
const money=v=>'$'+Number(v||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
function msg(id,t,bad=false){const n=$(id);if(!n)return;n.textContent=t||'';n.classList.toggle('error',!!bad)}
function busy(id,on,label){const b=$(id);if(!b)return;b.disabled=on;if(label)b.textContent=on?'Please wait…':label}
function esc(v){return String(v??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function table(rows,cols){if(!rows||!rows.length)return '<p class="muted">No records yet.</p>';return '<table><thead><tr>'+cols.map(c=>'<th>'+c[1]+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+cols.map(c=>'<td>'+esc(r[c[0]])+'</td>').join('')+'</tr>').join('')+'</tbody></table>'}
async function requireSession(){
 const {data,error}=await db.auth.getSession();
 if(error||!data.session){location.href='login.html';return false}
 currentUser=data.session.user;
 const {data:p,error:pe}=await db.from('profiles').select('*').eq('id',currentUser.id).single();
 if(pe){msg('pageMsg','Could not load your profile: '+pe.message,true);return false}
 currentProfile=p;
 const email=$('userEmail');if(email)email.textContent=currentUser.email||'';
 const admin=$('adminLink');if(admin)admin.classList.toggle('hidden',p.role!=='admin');
 const profileEmail=$('profileEmail');if(profileEmail)profileEmail.textContent=currentUser.email||'';
 const profileId=$('profileId');if(profileId)profileId.textContent=currentUser.id;
 const ref=$('referralCode');if(ref)ref.textContent=p.referral_code||'Not assigned';
 return true;
}
async function metrics(){
 const [d,t]=await Promise.all([
  db.from('deposits').select('amount').eq('user_id',currentUser.id).eq('status','approved'),
  db.from('trades').select('profit_loss').eq('user_id',currentUser.id)
 ]);
 const dep=$('totalDeposits'),pnl=$('totalPnl');
 if(dep)dep.textContent=money((d.data||[]).reduce((s,x)=>s+Number(x.amount||0),0));
 if(pnl)pnl.textContent=money((t.data||[]).reduce((s,x)=>s+Number(x.profit_loss||0),0));
 if(d.error)msg('pageMsg','Could not load deposit totals: '+d.error.message,true);
}
async function history(){
 const jobs=[
 ['depositHistory','deposits','amount,network,status,transaction_hash',[['amount','USD'],['network','Network'],['status','Status'],['transaction_hash','Transaction hash']]],
 ['tradeHistory','trades','asset,trade_type,amount,profit_loss',[['asset','Asset'],['trade_type','Type'],['amount','Amount'],['profit_loss','P/L']]],
 ['withdrawHistory','withdrawal_requests','amount,status,payment_details',[['amount','USD'],['status','Status'],['payment_details','Payout details']]],
 ['commissionHistory','referral_commissions','level,amount,status',[['level','Level'],['amount','USD'],['status','Status']]]
 ];
 await Promise.all(jobs.map(async ([target,tableName,fields,cols])=>{
  const el=$(target);if(!el)return;
  const key=tableName==='referral_commissions'?'beneficiary_id':'user_id';
  const {data,error}=await db.from(tableName).select(fields).eq(key,currentUser.id);
  el.innerHTML=error?esc(error.message):table(data,cols);
 }));
}
async function loadAdmin(){
 if(!currentProfile||currentProfile.role!=='admin'){$('adminDenied')?.classList.remove('hidden');return}
 $('adminContent')?.classList.remove('hidden');
 const {data,error}=await db.from('deposits').select('id,user_id,amount,network,transaction_hash').eq('status','pending').order('created_at',{ascending:true});
 if(error){$('pendingDeposits').textContent=error.message;return}
 $('pendingDeposits').innerHTML=(data||[]).map(d=>`<div class="wallet"><b>${money(d.amount)} · ${esc(d.network)}</b><p class="small muted">User: ${esc(d.user_id)}<br>Transaction: ${esc(d.transaction_hash)}</p><button class="copy" data-review="${esc(d.id)}" data-status="approved">Approve</button> <button class="copy" data-review="${esc(d.id)}" data-status="rejected">Reject</button></div>`).join('')||'No pending deposits.';
}
async function reviewDeposit(id,status){
 try{const {error}=await db.rpc('admin_review_deposit',{deposit_id:id,new_status:status});if(error)throw error;msg('pageMsg','Deposit marked '+status+'.');await loadAdmin();await metrics()}
 catch(e){msg('pageMsg','Review failed: '+e.message,true)}
}
async function logout(){await db.auth.signOut();location.href='login.html'}
document.addEventListener('click',async e=>{
 const review=e.target.closest('[data-review]');if(review){await reviewDeposit(review.dataset.review,review.dataset.status);return}
 const copy=e.target.closest('[data-copy]');if(copy){const text=$(copy.dataset.copy)?.textContent||'';try{await navigator.clipboard.writeText(text);msg('pageMsg','Copied.')}catch(_){msg('pageMsg','Copy unavailable. Select and copy manually.',true)}}
});
async function initAuth(){
 const page=document.body.dataset.page;
 if(page==='signup'){
  $('signupForm')?.addEventListener('submit',async e=>{
   e.preventDefault();msg('authMsg','');
   if($('signupPassword').value!==$('confirmPassword').value){msg('authMsg','The passwords do not match.',true);return}
   busy('signupBtn',true);
   try{
    const email=$('signupEmail').value.trim(),password=$('signupPassword').value,full_name=$('fullName').value.trim(),referral_code=$('referralInput').value.trim().toUpperCase()||null;
    const {data,error}=await db.auth.signUp({email,password,options:{data:{full_name,referral_code}}});if(error)throw error;
    if(data.session){location.href='dashboard.html';return}
    $('signupForm').classList.add('hidden');$('verifyForm').classList.remove('hidden');$('verifyEmail').value=email;msg('authMsg','Check your email for the 6-digit verification code.');
   }catch(err){msg('authMsg',err.message||'Registration failed.',true)}finally{busy('signupBtn',false,'Sign Up')}
  });
  $('verifyForm')?.addEventListener('submit',async e=>{
   e.preventDefault();busy('verifyBtn',true);
   try{const {error}=await db.auth.verifyOtp({email:$('verifyEmail').value.trim(),token:$('verifyToken').value.trim(),type:'signup'});if(error)throw error;msg('authMsg','Email verified. You can now log in.');location.href='login.html'}
   catch(err){msg('authMsg',err.message||'Verification failed.',true)}finally{busy('verifyBtn',false,'Verify email')}
  });
 }else if(page==='login'){
  $('loginForm')?.addEventListener('submit',async e=>{
   e.preventDefault();busy('loginBtn',true);
   try{const {data,error}=await db.auth.signInWithPassword({email:$('loginEmail').value.trim(),password:$('loginPassword').value});if(error)throw error;location.href='dashboard.html'}
   catch(err){msg('authMsg',err.message||'Login failed.',true)}finally{busy('loginBtn',false,'Log In')}
  });
 }else{
  if(!await requireSession())return;
  if(page==='dashboard')await metrics();
  if(page==='history')await history();
  if(page==='admin')await loadAdmin();
  $('logoutLink')?.addEventListener('click',e=>{e.preventDefault();logout()});
  $('depositForm')?.addEventListener('submit',async e=>{
   e.preventDefault();busy('depositBtn',true);
   try{const amount=Number($('depositAmount').value);if(!(amount>0))throw new Error('Enter a valid amount.');
    const {error}=await db.from('deposits').insert({user_id:currentUser.id,amount,network:$('depositNetwork').value,transaction_hash:$('depositHash').value.trim()});if(error)throw error;e.target.reset();msg('pageMsg','Deposit request submitted for manual review.')}
   catch(err){msg('pageMsg',err.message,true)}finally{busy('depositBtn',false,'Submit for review')}
  });
  $('withdrawForm')?.addEventListener('submit',async e=>{
   e.preventDefault();busy('withdrawBtn',true);
   try{const amount=Number($('withdrawAmount').value);if(!(amount>0))throw new Error('Enter a valid amount.');
    const {error}=await db.from('withdrawal_requests').insert({user_id:currentUser.id,amount,payment_details:$('withdrawDetails').value.trim()});if(error)throw error;e.target.reset();msg('pageMsg','Withdrawal request submitted for review.')}
   catch(err){msg('pageMsg',err.message,true)}finally{busy('withdrawBtn',false,'Submit withdrawal request')}
  });
  $('tradeForm')?.addEventListener('submit',async e=>{
   e.preventDefault();busy('tradeBtn',true);
   try{const {error}=await db.rpc('admin_add_trade',{p_user_id:$('tradeUser').value.trim(),p_asset:$('tradeAsset').value.trim(),p_trade_type:$('tradeType').value,p_amount:Number($('tradeAmount').value),p_profit_loss:Number($('tradePnl').value)});if(error)throw error;e.target.reset();msg('pageMsg','Trade record saved.')}
   catch(err){msg('pageMsg','Could not save trade: '+err.message,true)}finally{busy('tradeBtn',false,'Save trade record')}
  });
  $('copyReferral')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(currentProfile.referral_code||'');msg('pageMsg','Referral code copied.')}catch(_){msg('pageMsg','Copy manually: '+(currentProfile.referral_code||'Not assigned'),true)}});
 }
}
document.addEventListener('DOMContentLoaded',initAuth);